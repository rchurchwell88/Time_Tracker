﻿using System;
namespace ChurchwellRussell_TimeTrackerApp
{
    public class Menus
    {
        public Menus()
        {
        }

        // Print main menu
        public static void PrintMenu()
        {

            Console.Clear();

            Console.WriteLine("1: Pick Activity");
            Console.WriteLine("2: View Tracked Data(Coming Soon)");
            Console.WriteLine("3: Run Calculations(Coming Soon)\n");

            Console.WriteLine("4: Exit\n");

            Console.Write("Choice: ");
        }

        // Print submenus based on SQL input
        public static void PrintActivitySub(string menu)
        {
            Console.Clear();

            Console.WriteLine(menu);

            Console.Write("Choice: ");
        }
    }
}
