﻿using System;
using MySql.Data.MySqlClient;

namespace ChurchwellRussell_TimeTrackerApp
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // vars for SQL
            MySqlCommand cmd;
            MySqlConnection conn;
            MySqlDataReader rdr;
            string Scmd;
            Utilities util = new Utilities();
            SQL sql = new SQL();
            string catFinal = null;
            bool menuRun = true;

            // Call conection
            conn = sql.Connect();

            while (menuRun)
            {
                Menus.PrintMenu();

                // Get menu input based on menu limit
                switch (util.GetIntLimit(4))
                {
                    // Pull categories
                    case 1:
                        PullAndPushCats();
                        break;

                    case 2:
                        {
                            Console.Clear();
                            Console.WriteLine("Coming soon");
                            util.GetKey();
                        }
                        break;

                    case 3:
                        {
                            Console.Clear();
                            Console.WriteLine("Coming soon");
                            util.GetKey();
                        }
                        break;

                    case 4:
                        menuRun = false;
                        break;
                }
            }

            

            // Pull categories from database
            void PullAndPushCats()
            {
                // Vars to handle this operation
                Console.Clear();
                Scmd = "select * from activity_categories;";
                cmd = new MySqlCommand(Scmd, conn);
                rdr = cmd.ExecuteReader();
                catFinal = null;

                // Loop to out results
                while(rdr.Read())
                {
                    catFinal+=$"{rdr.GetInt32("activity_category_id")}: ";
                    catFinal+=rdr.GetString("category_description")+"\n";
                }

                // Close reader
                rdr.Close();

                // Print and assign category choices
                Menus.PrintActivitySub(catFinal);
                int catChoice = util.GetIntLimit(2);

                // New command to pull selected info
                Scmd = $"select activity_category_id, activity_description from activity_categories " +
                    $"join activity_descriptions on activity_categories.`activity_category_id`" +
                    $"=`activity_description_id` where `activity_category_id`= {catChoice}";
                cmd = new MySqlCommand(Scmd, conn);

                // Open Reader
                rdr = cmd.ExecuteReader();

                // Step through selection to add vals to database.
                int iterator = 1;
                Console.Clear();

                // Restart vars for submenu.
                catFinal = null;
                while(rdr.Read())
                {
                    catFinal+=$"{iterator}: ";
                    catFinal+= rdr.GetString("activity_description")+"\n";

                    iterator++;
                }
                rdr.Close();

                // Get submenu choices
                Menus.PrintActivitySub(catFinal);
                int catDChoice = util.GetIntLimit(2);

                // Iterator to list description
                iterator = 1;
                Console.Clear();

                // Reader vars to pull SQL data
                rdr = cmd.ExecuteReader();
                catFinal = null;
                while(rdr.Read())
                {
                    if(iterator==catDChoice)
                    {
                        catFinal += rdr.GetString("activity_description");
                    }

                    iterator++;
                }

                // Out data and close reader
                Console.WriteLine(catFinal);
                rdr.Close();

                // Re assign query to insert SQL data
                string query = "insert into activity_log(activity_description, " +
                    $"category_description) values(@activity_description, @category_description)";

                // Create push object
                MySqlCommand run = new MySqlCommand(query, conn);

                // Create push statements
                run.Parameters.AddWithValue("@activity_description", catChoice);
                run.Parameters.AddWithValue("@category_description", catDChoice);

                // Push data
                run.ExecuteNonQuery();

            }
        }
    }
}
